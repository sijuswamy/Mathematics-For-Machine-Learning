# College_Statistics_with_Python
We use Python to get intuition on complex concepts, empirically test theoretical proofs, or build algorithms from scratch

In a series of weekly articles, I will be covering some important topics of statistics with a twist.  

The goal is to use Python to help us get intuition on complex concepts, empirically test theoretical proofs, or build algorithms from scratch. In this series, you will find articles covering topics such as random variables, sampling distributions, confidence intervals, significance tests, and more.  

At the end of each article, you can find exercises to test your knowledge. The solutions will be shared in the article of the following week.
